﻿#说明：在build目录，
先删除CMakeCache.txt,之行cmake . 
       .表示CmakeLists文件在当前目录，会生成新的Makefile
       然后执行make,即可生成可执行文件